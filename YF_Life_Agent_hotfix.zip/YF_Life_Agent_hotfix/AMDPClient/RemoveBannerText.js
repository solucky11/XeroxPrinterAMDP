var msiOpenDatabaseModeTransact = 1;

if (WScript.Arguments.Length != 1) {
    WScript.StdErr.WriteLine(WScript.ScriptName + " file");
    WScript.Quit(1);
}

WScript.Echo(WScript.Arguments(0));
var filespec = WScript.Arguments(0);
WScript.Echo("Create Object");
var installer = WScript.CreateObject("WindowsInstaller.Installer");
WScript.Echo("Connect to database");
var database = installer.OpenDatabase(filespec, msiOpenDatabaseModeTransact);

var sql
var view

try {
    /*
    sql = "SELECT Type, Text, Attributes FROM Control WHERE Type='Text'";
    view = database.OpenView(sql);
    view.Execute();
    record = view.Fetch();
    while (record) {
        WScript.Echo(record.StringData(1));
        WScript.Echo(record.StringData(2));
        WScript.Echo(record.StringData(3));
        record = view.Fetch();
    }
    */

    //Update InstallUISequence to support command-line parameters in interactive mode. 
    sql = "UPDATE Control SET Text = '' WHERE Type='Text' and Attributes = 196611";
    view = database.OpenView(sql);
    view.Execute();
    view.Close();
    database.Commit();
    WScript.Echo("Finish");
}
catch (e) {
    WScript.Echo("Error:");
    WScript.Echo(e);
    WScript.StdErr.WriteLine(e);
    WScript.Quit(1);
} 